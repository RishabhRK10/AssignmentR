var person={
name: "Rishabh";
gender: "Male";
description:"Engineer"
}

function myfunction() {
console.log(person)
}