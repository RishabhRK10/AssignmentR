function functionone(){
	document.getElementById("new1").innerHTML="Recipes for Killer Mushrooms";
	document.getElementById("new2").innerHTML="In a medium skillet, over a high heat, melt the butter. Saute the mushrooms 3 to 4 minutes. Add the onion, cook until translucent then add the garlic for a minute or so, then the spices. Cook until the mixture is fairly dry.";
}
function functiontwo(){
	document.getElementById("new1").innerHTML="Recipes for Celery Root";
	document.getElementById("new2").innerHTML="Puree the vegetables with a little of the cooking liquid, a bit of cream, and salt and pepper. 9. Instead of a puree, make a celery root “mash” by hand-mashing cooked celery root and potatoes together with butter and milk and a little sautéed garlic. Serve with pot roast.";
}
function functionthree(){
	document.getElementById("new1").innerHTML="Recipes for Spaghetti Squash";
	document.getElementById("new2").innerHTML="Heat a large saute pan with the butter and the garlic over medium-low heat. When garlic becomes fragrant, add parsley, salt and spaghetti squash strands. Toss well, sprinkle in the parmesan cheese and taste to see if you need additional salt.";
}
function functionfour(){
	document.getElementById("new3").innerHTML="Recipes for Celery Root";
	document.getElementById("new4").innerHTML="Puree the vegetables with a little of the cooking liquid, a bit of cream, and salt and pepper. 9. Instead of a puree, make a celery root “mash” by hand-mashing cooked celery root and potatoes together with butter and milk and a little sautéed garlic. Serve with pot roast.";
}
function functionfive(){
	document.getElementById("new3").innerHTML="Recipes for Killer Mushrooms";
	document.getElementById("new4").innerHTML="In a medium skillet, over a high heat, melt the butter. Saute the mushrooms 3 to 4 minutes. Add the onion, cook until translucent then add the garlic for a minute or so, then the spices. Cook until the mixture is fairly dry.";
}
function functionsix(){
	document.getElementById("new3").innerHTML="Recipes for Spaghetti Squash";
	document.getElementById("new4").innerHTML="Heat a large saute pan with the butter and the garlic over medium-low heat. When garlic becomes fragrant, add parsley, salt and spaghetti squash strands. Toss well, sprinkle in the parmesan cheese and taste to see if you need additional salt.";
}
function functiontop(){
	document.getElementById("new5").innerHTML="Celery Root";
	document.getElementById("new6").innerHTML="In a medium skillet, over a high heat, melt the butter. Saute the mushrooms 3 to 4 minutes. Add the onion, cook until translucent then add the garlic for a minute or so, then the spices. Cook until the mixture is fairly dry.";
}
function functionmiddle(){
	document.getElementById("new5").innerHTML="Spaghetti Squash";
	document.getElementById("new6").innerHTML="Heat a large saute pan with the butter and the garlic over medium-low heat. When garlic becomes fragrant, add parsley, salt and spaghetti squash strands. Toss well, sprinkle in the parmesan cheese and taste to see if you need additional salt.";
}
function functionbottom(){
	document.getElementById("new5").innerHTML="killer Mushrooms";
	document.getElementById("new6").innerHTML="In a medium skillet, over a high heat, melt the butter. Saute the mushrooms 3 to 4 minutes. Add the onion, cook until translucent then add the garlic for a minute or so, then the spices. Cook until the mixture is fairly dry.";
}